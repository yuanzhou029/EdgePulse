#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
fetch_socks5.py
海量公网 SOCKS5 代理抓取、去重与 VPS 真实测活工具

特性：
  1. 多源并发抓取：集成多个高质量公网 SOCKS5 订阅源 + 用户自定义源 + 本地 custom_socks5.txt
  2. 智能解析：支持 ip:port、socks5://[user:pass@]host:port、base64 订阅等
  3. 优先调度：用户私有源与本地自定义源优先探测，公开源补充候选
  4. 真实测活：调用 VPS 探测 API，验证真实 TLS 握手及目标网站连通性
  5. 自动打标：根据真实出口 IP 自动识别国家中文名与机房/家宽属性（如 #美国-机房、#日本-家宽）
  6. 目标熔断：支持 --target-alive，测够所需存活节点数即可提前完成，省时高效
"""

import sys
import os
import re
import json
import time
import base64
import argparse
import urllib.request
import urllib.error

# 解决 Windows 控制台 utf-8 编码输出问题
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ============================ 核心配置 ============================

# VPS 探测 API 配置（可通过环境变量覆盖）
PROBE_API_URL = os.environ.get("PROBE_API_URL", "https://8787-agqxk6eozxdhet7cudioaeegmi.instabox.tech").rstrip("/")
PROBE_TOKEN = os.environ.get("PROBE_TOKEN", "pi3gxKKeN7Abi94wGgEU6B")

# 请求默认 Header
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# 默认优先与公共 SOCKS5 数据源
DEFAULT_SOURCES = [
    # 1. 用户私有/特权源（优先置顶）
    {
        "name": "用户自定义源",
        "url": "https://gx.51281868.xyz/SSTP.txt?token=yuanzhou029",
        "priority": True
    },
    # 2. 本地自定义文件（方便随时粘入新节点）
    {
        "name": "本地自定义源",
        "file": "custom_socks5.txt",
        "priority": True
    },
    # 3. 高质量开源 SOCKS5 源（小时级更新，存活率相对较高）
    {
        "name": "monosans/proxy-list",
        "url": "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
        "priority": False
    },
    # 4. ProxyScrape 实时 API（5秒内可用筛选）
    {
        "name": "ProxyScrape API",
        "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=5000&country=all",
        "priority": False
    },
    # 5. TheSpeedX 公共代理源
    {
        "name": "TheSpeedX SOCKS5",
        "url": "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
        "priority": False
    }
]

# 国家/地区代码转中文映射表
GEO_NAMES_ZH = {
    "JP": "日本",
    "KR": "韩国",
    "US": "美国",
    "HK": "香港",
    "TW": "台湾",
    "SG": "新加坡",
    "GB": "英国",
    "DE": "德国",
    "FR": "法国",
    "CA": "加拿大",
    "AU": "澳大利亚",
    "RU": "俄罗斯",
    "IN": "印度",
    "TH": "泰国",
    "VN": "越南",
    "MY": "马来西亚",
    "ID": "印尼",
    "PH": "菲律宾",
    "NL": "荷兰",
    "BR": "巴西",
    "ZA": "南非",
    "UA": "乌克兰",
    "TR": "土耳其",
    "ES": "西班牙",
    "IT": "意大利",
    "SE": "瑞典",
    "CH": "瑞士",
    "PL": "波兰",
    "NO": "挪威",
    "FI": "芬兰",
    "AR": "阿根廷",
    "CL": "智利",
    "CO": "哥伦比亚",
    "MX": "墨西哥",
    "NZ": "新西兰",
    "IE": "爱尔兰",
    "AT": "奥地利",
    "BE": "比利时",
    "CZ": "捷克",
    "DK": "丹麦",
    "PT": "葡萄牙",
    "RO": "罗马尼亚",
    "HU": "匈牙利",
    "IL": "以色列",
    "AE": "阿联酋",
    "IR": "伊朗",
    "EG": "埃及",
    "PK": "巴基斯坦",
    "BD": "孟加拉",
    "NG": "尼日利亚",
    "KE": "肯尼亚"
}

COUNTRY_NAME_TO_ZH = {
    "United States": "美国", "United States of America": "美国", "US": "美国", "USA": "美国",
    "Canada": "加拿大", "CA": "加拿大",
    "Japan": "日本", "JP": "日本",
    "South Korea": "韩国", "Korea": "韩国", "Republic of Korea": "韩国", "KR": "韩国",
    "Hong Kong": "香港", "HK": "香港",
    "Taiwan": "台湾", "TW": "台湾",
    "Singapore": "新加坡", "SG": "新加坡",
    "United Kingdom": "英国", "GB": "英国", "UK": "英国",
    "Germany": "德国", "DE": "德国",
    "France": "法国", "FR": "法国",
    "Russia": "俄罗斯", "Russian Federation": "俄罗斯", "RU": "俄罗斯",
    "Australia": "澳大利亚", "AU": "澳大利亚",
    "India": "印度", "IN": "印度",
    "Thailand": "泰国", "TH": "泰国",
    "Vietnam": "越南", "Viet Nam": "越南", "VN": "越南",
    "Malaysia": "马来西亚", "MY": "马来西亚",
    "Indonesia": "印尼", "ID": "印尼",
    "Philippines": "菲律宾", "PH": "菲律宾",
    "Netherlands": "荷兰", "NL": "荷兰",
    "Brazil": "巴西", "BR": "巴西",
    "Turkey": "土耳其", "TR": "土耳其",
    "Spain": "西班牙", "ES": "西班牙",
    "Italy": "意大利", "IT": "意大利",
    "Sweden": "瑞典", "SE": "瑞典",
    "Switzerland": "瑞士", "CH": "瑞士",
    "Poland": "波兰", "PL": "波兰",
    "Romania": "罗马尼亚", "RO": "罗马尼亚",
    "Iran": "伊朗", "Islamic Republic of Iran": "伊朗",
    "Egypt": "埃及", "Pakistan": "巴基斯坦", "Bangladesh": "孟加拉"
}

def format_node_tag(country_code, country_name, is_datacenter):
    """统一生成标准节点标签：国家-家宽/机房"""
    country_zh = (
        GEO_NAMES_ZH.get((country_code or "").upper()) or
        COUNTRY_NAME_TO_ZH.get(country_name) or
        country_name or
        "未知"
    )
    isp_tag = "机房" if is_datacenter else "家宽"
    return f"{country_zh}-{isp_tag}"

# ============================ 节点解析与抓取 ============================

def parse_socks5_line(line):
    """
    解析单行输入为标准 socks5:// 格式
    支持：
      - socks5://user:pass@host:port#tag
      - socks5://host:port
      - host:port
    """
    raw = line.strip()
    if not raw or raw.startswith("#") or raw.startswith("//"):
        return None

    # 分离现有 tag
    tag = ""
    if "#" in raw:
        parts = raw.split("#", 1)
        raw = parts[0].strip()
        tag = parts[1].strip()

    # 如果带协议
    if "://" in raw:
        proto, rest = raw.split("://", 1)
        if proto.lower() != "socks5":
            return None  # 仅处理 SOCKS5
        auth_host = rest.split("/")[0].strip()
    else:
        auth_host = raw.split("/")[0].strip()

    if not auth_host:
        return None

    auth = ""
    host_port = auth_host
    if "@" in auth_host:
        auth, host_port = auth_host.rsplit("@", 1)

    # 提取 host 与 port
    if host_port.startswith("["):
        # IPv6
        close_idx = host_port.find("]")
        if close_idx == -1:
            return None
        host = host_port[:close_idx + 1]
        port_part = host_port[close_idx + 1:]
        if not port_part.startswith(":"):
            return None
        port = port_part[1:]
    else:
        if ":" not in host_port:
            return None
        host, port = host_port.rsplit(":", 1)

    # 校验端口合法性
    if not port.isdigit() or not (1 <= int(port) <= 65535):
        return None

    auth_str = f"{auth}@" if auth else ""
    tag_str = f"#{tag}" if tag else ""
    return f"socks5://{auth_str}{host}:{port}{tag_str}"

def normalize_node_key(node_str):
    """提取唯一键 host:port 用于精准去重"""
    raw = node_str.split("#")[0].strip()
    if "://" in raw:
        raw = raw.split("://", 1)[1]
    if "@" in raw:
        raw = raw.rsplit("@", 1)[1]
    return raw.lower()

def fetch_source_content(source_item):
    """读取指定数据源的内容（URL 或本地文件）"""
    name = source_item.get("name", "未知源")
    url = source_item.get("url")
    file_path = source_item.get("file")

    if file_path:
        if not os.path.exists(file_path):
            # 如果本地文件不存在，自动创建模板
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write("# 在此处粘贴您的自定义 SOCKS5 节点（每行一个）\n# 示例：\n# socks5://user:pass@1.2.3.4:1080#自定义备注\n# 1.2.3.4:1080\n")
            except Exception:
                pass
            return []
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
            print(f"[*] 读取本地源 [{name}]: {len(lines)} 行")
            return lines
        except Exception as e:
            print(f"[!] 读取本地源 [{name}] 失败: {e}", file=sys.stderr)
            return []

    if url:
        print(f"[*] 正在拉取远程源 [{name}]: {url} ...")
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=12) as resp:
                raw_bytes = resp.read()
                # 尝试 base64 解码
                try:
                    decoded = base64.b64decode(raw_bytes).decode("utf-8")
                    lines = decoded.splitlines()
                except Exception:
                    lines = raw_bytes.decode("utf-8", errors="ignore").splitlines()
                print(f"[+] 远程源 [{name}] 拉取成功: 得到 {len(lines)} 行原始数据")
                return lines
        except Exception as e:
            print(f"[!] 远程源 [{name}] 拉取失败: {e}", file=sys.stderr)
            return []

    return []

# ============================ 批量测活逻辑 ============================

def check_socks5_alive(nodes, api_url=PROBE_API_URL, token=PROBE_TOKEN, chunk_size=20, timeout=40, target_alive=0, output_file="alive_socks5.txt"):
    """
    分批调用 VPS 探测 API 进行真实连通性测活
    """
    if not nodes:
        print("[!] 没有待检测的候选节点", file=sys.stderr)
        return []

    total = len(nodes)
    alive_nodes = []
    dead_count = 0
    start_time = time.time()
    batch_url = f"{api_url}/check/batch"
    headers = {
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    print(f"\n[*] 开始通过 VPS 探测 API 进行真实连通性测活...")
    print(f"[*] API 地址: {batch_url}")
    print(f"[*] 待测节点: {total} 个 | 每批次并发: {chunk_size} 个" + (f" | 熔断目标: {target_alive} 个存活" if target_alive > 0 else ""))
    print("-" * 75)

    batch_num = 0
    total_batches = (total + chunk_size - 1) // chunk_size

    for i in range(0, total, chunk_size):
        batch_num += 1
        chunk = nodes[i:i + chunk_size]
        print(f"[*] 正在探测第 {batch_num}/{total_batches} 批 ({len(chunk)} 个节点)...")

        payload = {"targets": chunk}
        data = json.dumps(payload).encode("utf-8")

        try:
            req = urllib.request.Request(batch_url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp_data = json.loads(resp.read().decode("utf-8"))

            results = resp_data.get("results", [])
            for r in results:
                target = r.get("input") or r.get("link") or ""
                success = r.get("success", False)
                resp_ms = r.get("responseTime", 0)

                if success:
                    exit_info = r.get("exit") or {}
                    exit_ip = exit_info.get("ip", "-")
                    exit_country = exit_info.get("country", "-")
                    exit_country_code = exit_info.get("country_code", "")
                    is_dc = exit_info.get("is_datacenter", False)

                    real_tag = format_node_tag(exit_country_code, exit_country, is_dc)
                    base_uri = target.split("#")[0].strip()
                    final_node = f"{base_uri}#{real_tag}"

                    try:
                        print(f"  [+] 存活 | {resp_ms:4d}ms | {exit_country} ({exit_ip}) | {final_node}")
                    except Exception:
                        print(f"  [+] 存活 | {resp_ms:4d}ms | {final_node}")
                    alive_nodes.append(final_node)
                else:
                    err = r.get("error") or "未知错误"
                    try:
                        print(f"  [-] 离线 | {resp_ms:4d}ms | {err} | {target}")
                    except Exception:
                        print(f"  [-] 离线 | {resp_ms:4d}ms | {target}")
                    dead_count += 1

        except urllib.error.HTTPError as e:
            err_msg = e.read().decode("utf-8", errors="ignore")
            print(f"  [!] 本批请求失败 (HTTP {e.code}): {err_msg}", file=sys.stderr)
            dead_count += len(chunk)
        except Exception as e:
            print(f"  [!] 本批请求异常: {e}", file=sys.stderr)
            dead_count += len(chunk)

        # 检查是否满足熔断目标
        if target_alive > 0 and len(alive_nodes) >= target_alive:
            print(f"\n[+] 已达到目标存活节点数量 ({len(alive_nodes)}/{target_alive})，提前终止探测！")
            break

    elapsed = time.time() - start_time
    alive_count = len(alive_nodes)
    print("-" * 75)
    print(f"[+] 测活完成！耗时: {elapsed:.1f}s | 探测总数: {len(alive_nodes) + dead_count} | 存活: {alive_count} | 离线: {dead_count}")

    if output_file and alive_nodes:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write("\n".join(alive_nodes) + "\n")
        print(f"[+] 存活 SOCKS5 节点已成功保存到: {output_file}")
    elif not alive_nodes:
        print(f"[!] 本轮未探测到存活节点，未写入 {output_file}")

    return alive_nodes

# ============================ 主流程 ============================

def main():
    parser = argparse.ArgumentParser(description="海量公网 SOCKS5 抓取与 VPS 测活工具")
    parser.add_argument("--max-candidates", type=int, default=300, help="最多保留的候选节点数量（默认 300）")
    parser.add_argument("--target-alive", type=int, default=15, help="目标存活数量，达到后自动熔断结束（默认 15，传 0 表示全量测完）")
    parser.add_argument("--chunk-size", type=int, default=15, help="每批次向 VPS 提交的节点并发数（默认 15）")
    parser.add_argument("--timeout", type=int, default=45, help="单批次请求超时时间秒（默认 45）")
    parser.add_argument("--output", default="alive_socks5.txt", help="存活节点输出文件（默认 alive_socks5.txt）")
    parser.add_argument("--candidates-file", default="socks5_nodes.txt", help="候选节点保存文件（默认 socks5_nodes.txt）")
    parser.add_argument("--no-check", action="store_true", help="仅抓取并导出候选节点，不进行 VPS 测活")
    args = parser.parse_args()

    print("=" * 75)
    print("           公网 SOCKS5 代理聚合提取与测活引擎 (方案3)")
    print("=" * 75)

    priority_candidates = []
    public_candidates = []
    seen_keys = set()

    # 1. 遍历各源拉取并解析
    for source in DEFAULT_SOURCES:
        lines = fetch_source_content(source)
        is_priority = source.get("priority", False)
        valid_in_source = 0

        for line in lines:
            node = parse_socks5_line(line)
            if not node:
                continue
            key = normalize_node_key(node)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            valid_in_source += 1

            if is_priority:
                priority_candidates.append(node)
            else:
                public_candidates.append(node)

        print(f"  -> 源 [{source.get('name')}] 贡献有效新节点: {valid_in_source} 个")

    # 2. 合并去重：私有源绝对优先置顶
    all_candidates = priority_candidates + public_candidates
    if args.max_candidates > 0 and len(all_candidates) > args.max_candidates:
        print(f"[*] 候选节点总数 ({len(all_candidates)}) 超过上限 ({args.max_candidates})，截断保留前 {args.max_candidates} 个...")
        all_candidates = all_candidates[:args.max_candidates]

    print(f"\n[+] 节点聚合完成：共精选出 {len(all_candidates)} 个 SOCKS5 待测候选 (优先源: {len(priority_candidates)}, 公共源: {len(all_candidates) - len(priority_candidates)})")

    if args.candidates_file:
        with open(args.candidates_file, "w", encoding="utf-8") as f:
            f.write("\n".join(all_candidates) + "\n")
        print(f"[+] 候选节点已写入: {args.candidates_file}")

    if args.no_check:
        print("[*] 参数已指定 --no-check，跳过测活流程。")
        return

    # 3. 执行测活
    check_socks5_alive(
        all_candidates,
        api_url=PROBE_API_URL,
        token=PROBE_TOKEN,
        chunk_size=args.chunk_size,
        timeout=args.timeout,
        target_alive=args.target_alive,
        output_file=args.output
    )

if __name__ == "__main__":
    main()
