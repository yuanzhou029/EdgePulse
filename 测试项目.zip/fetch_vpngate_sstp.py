import urllib.request
import urllib.error
import json
import base64
import csv
import re
import sys
import os
import time

# 确保在 Windows 控制台或管道下输出中文时不发生编码异常
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

VPNGATE_API = "https://www.vpngate.net/api/iphone/"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

# 自定义节点获取渠道（支持 URL 列表，也支持本地文件路径方便手动粘贴添加）
CUSTOM_SOURCES = [
    "https://gx.51281868.xyz/SSTP.txt?token=yuanzhou029",
    "custom_nodes.txt",  # 本地文件（如果存在则自动读取）
]

# VPS 探测 API 配置（可通过环境变量覆盖）
PROBE_API_URL = os.environ.get("PROBE_API_URL", "https://8787-agqxk6eozxdhet7cudioaeegmi.instabox.tech").rstrip("/")
PROBE_TOKEN = os.environ.get("PROBE_TOKEN", "pi3gxKKeN7Abi94wGgEU6B")


# 国家/地区代码转中文映射表
GEO_NAMES_ZH = {
    "JP": "日本",
    "KR": "韩国",
    "US": "美国",
    "HK": "香港",
    "TW": "台湾",
    "SG": "新加坡",
    "GB": "英国",
    "DE": "德国",
    "FR": "法国",
    "CA": "加拿大",
    "AU": "澳大利亚",
    "RU": "俄罗斯",
    "IN": "印度",
    "TH": "泰国",
    "VN": "越南",
    "MY": "马来西亚",
    "ID": "印尼",
    "PH": "菲律宾",
    "NL": "荷兰",
    "BR": "巴西",
    "ZA": "南非",
    "UA": "乌克兰",
    "TR": "土耳其",
    "ES": "西班牙",
    "IT": "意大利",
    "SE": "瑞典",
    "CH": "瑞士",
    "PL": "波兰",
    "NO": "挪威",
    "FI": "芬兰",
    "AR": "阿根廷",
    "CL": "智利",
    "CO": "哥伦比亚",
    "MX": "墨西哥",
    "NZ": "新西兰",
    "IE": "爱尔兰",
    "AT": "奥地利",
    "BE": "比利时",
    "CZ": "捷克",
    "DK": "丹麦",
    "PT": "葡萄牙",
    "RO": "罗马尼亚",
    "HU": "匈牙利",
    "IL": "以色列",
    "AE": "阿联酋",
}

# 英文国家全名转中文映射表（用于补充 probe API 或外部接口返回的全名）
COUNTRY_NAME_TO_ZH = {
    "United States": "美国", "United States of America": "美国", "US": "美国", "USA": "美国",
    "Canada": "加拿大", "CA": "加拿大",
    "Japan": "日本", "JP": "日本",
    "South Korea": "韩国", "Korea": "韩国", "Republic of Korea": "韩国", "KR": "韩国",
    "Hong Kong": "香港", "HK": "香港",
    "Taiwan": "台湾", "TW": "台湾",
    "Singapore": "新加坡", "SG": "新加坡",
    "United Kingdom": "英国", "GB": "英国", "UK": "英国",
    "Germany": "德国", "DE": "德国",
    "France": "法国", "FR": "法国",
    "Russia": "俄罗斯", "Russian Federation": "俄罗斯", "RU": "俄罗斯",
    "Australia": "澳大利亚", "AU": "澳大利亚",
    "India": "印度", "IN": "印度",
    "Thailand": "泰国", "TH": "泰国",
    "Vietnam": "越南", "Viet Nam": "越南", "VN": "越南",
    "Malaysia": "马来西亚", "MY": "马来西亚",
    "Indonesia": "印尼", "ID": "印尼",
    "Philippines": "菲律宾", "PH": "菲律宾",
    "Netherlands": "荷兰", "NL": "荷兰",
    "Brazil": "巴西", "BR": "巴西",
    "Turkey": "土耳其", "TR": "土耳其",
    "Spain": "西班牙", "ES": "西班牙",
    "Italy": "意大利", "IT": "意大利",
    "Sweden": "瑞典", "SE": "瑞典",
    "Switzerland": "瑞士", "CH": "瑞士",
    "Poland": "波兰", "PL": "波兰",
    "Romania": "罗马尼亚", "RO": "罗马尼亚",
}

def format_node_tag(country_code, country_name, is_datacenter):
    """生成统一格式的节点标签：国家-家宽/机房"""
    country_zh = (
        GEO_NAMES_ZH.get((country_code or "").upper()) or
        COUNTRY_NAME_TO_ZH.get(country_name) or
        country_name or
        "未知"
    )
    isp_tag = "机房" if is_datacenter else "家宽"
    return f"{country_zh}-{isp_tag}"

def extract_node_host(node_str):
    """从节点链接中提取主机名或 IP（去掉协议、认证和端口）"""
    raw = node_str.split("#")[0].strip()
    if "://" in raw:
        raw = raw.split("://", 1)[1]
    if "@" in raw:
        raw = raw.split("@", 1)[1]
    if raw.startswith("["):
        return raw.split("]")[0].strip("[")
    return raw.split(":")[0]

# 常见机房/云厂商关键字过滤规则
HOSTING_KEYWORDS_REGEX = re.compile(
    r"\b(vps|cloud|server|datacenter|dedicated|hosting|host|ovh|linode|digitalocean|"
    r"vultr|aws|amazon|azure|google|oracle|alibaba|tencent|hetzner|choopa|leaseweb|"
    r"contabo|kamatera|upcloud)\b",
    re.I
)

def batch_query_isp_type(ips):
    """
    使用 ip-api.com/batch 批量查询 IP 的机房/家宽属性 (hosting 字段) 及国家代码
    单次最多支持 100 个 IP，免 API Key
    返回: { "ip": { "tag": "机房"|"家宽", "country_code": "...", "country": "..." } }
    """
    isp_map = {}
    if not ips:
        return isp_map

    chunk_size = 100
    total = len(ips)
    print(f"[*] 正在批量查询 {total} 个节点的地理与家宽/机房属性...")

    for i in range(0, total, chunk_size):
        chunk = ips[i:i + chunk_size]
        query_payload = [{"query": ip, "fields": "query,hosting,org,isp,countryCode,country"} for ip in chunk]
        
        try:
            req = urllib.request.Request(
                "http://ip-api.com/batch",
                data=json.dumps(query_payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": USER_AGENT}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                for item in data:
                    ip = item.get("query")
                    is_hosting = item.get("hosting", False)
                    org_isp = f"{item.get('org', '')} {item.get('isp', '')}"
                    tag = "机房" if (is_hosting or HOSTING_KEYWORDS_REGEX.search(org_isp)) else "家宽"
                    isp_map[ip] = {
                        "tag": tag,
                        "country_code": item.get("countryCode", ""),
                        "country": item.get("country", "")
                    }
        except Exception as e:
            # 查询超时或失败时的保底策略
            for ip in chunk:
                isp_map[ip] = {"tag": "家宽", "country_code": "", "country": ""}

    return isp_map

def fetch_custom_nodes(sources=None):
    """
    从自定义渠道（远程 URL 或本地文本文件）拉取节点列表
    支持格式：
      - 明文多行 (sstp://..., socks5://..., http://..., https://...)
      - base64 编码的整包订阅
      - 纯 host:port 格式
    """
    if sources is None:
        sources = CUSTOM_SOURCES

    if isinstance(sources, str):
        sources = [s.strip() for s in sources.split(",") if s.strip()]

    custom_nodes = []
    for src in sources:
        if not src:
            continue
        text = ""
        is_url = src.startswith("http://") or src.startswith("https://")
        if is_url:
            print(f"[*] 正在拉取自定义数据源: {src} ...")
            req = urllib.request.Request(src, headers={"User-Agent": USER_AGENT})
            try:
                with urllib.request.urlopen(req, timeout=15) as resp:
                    text = resp.read().decode("utf-8", errors="ignore")
            except Exception as e:
                print(f"[!] 拉取自定义数据源失败 ({src}): {e}", file=sys.stderr)
                continue
        else:
            # 本地文件
            if not os.path.exists(src):
                if src != "custom_nodes.txt":
                    print(f"[!] 本地数据源文件不存在: {src}", file=sys.stderr)
                continue
            print(f"[*] 正在读取本地自定义数据源文件: {src} ...")
            try:
                with open(src, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
            except Exception as e:
                print(f"[!] 读取本地数据源失败 ({src}): {e}", file=sys.stderr)
                continue

        # 尝试 base64 解码（如遇到整包订阅）
        cleaned = text.strip()
        if "://" not in cleaned and re.match(r"^[A-Za-z0-9+/=\s]+$", cleaned):
            try:
                b64_decoded = base64.b64decode(re.sub(r"\s+", "", cleaned)).decode("utf-8", errors="ignore")
                if "://" in b64_decoded:
                    cleaned = b64_decoded
            except Exception:
                pass

        count_before = len(custom_nodes)
        for raw_line in cleaned.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or line.startswith("//"):
                continue
            # 支持常见代理协议
            if any(line.lower().startswith(f"{p}://") for p in ("sstp", "socks5", "http", "https")):
                custom_nodes.append(line)
            elif re.match(r"^(\[[0-9a-f:]+\]|[^\s:/]+):\d{1,5}", line):
                # 纯 host:port 默认包装为 sstp
                custom_nodes.append(f"sstp://vpn:vpn@{line}")

        added = len(custom_nodes) - count_before
        print(f"[+] 自定义源 ({src}) 成功解析出 {added} 个候选节点")

    return custom_nodes

def normalize_node_key(node_str):
    """
    提取核心连接属性（协议+认证+主机+端口）进行去重，忽略 #备注
    """
    return node_str.split("#")[0].strip().lower()

def fetch_vpngate_sstp(use_ip=False, check_isp=True, output_file="sstp_nodes.txt",
                       custom_sources=CUSTOM_SOURCES,
                       check_alive=True, alive_output_file="alive_sstp.txt",
                       api_url=PROBE_API_URL, token=PROBE_TOKEN, chunk_size=25):
    """
    抓取 VPNGate 并整理为带有中文地区和【家宽/机房】标签的 SSTP 节点
    同时融合自定义渠道（URL或本地文件），去重并调用 VPS API 测活导出
    """
    print(f"[*] 正在拉取 VPNGate 官方数据: {VPNGATE_API} ...")
    req = urllib.request.Request(VPNGATE_API, headers={"User-Agent": USER_AGENT})

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            content = resp.read().decode("utf-8", errors="ignore")
    except Exception as e:
        print(f"[!] 拉取失败: {e}", file=sys.stderr)
        return []

    lines = [line.strip() for line in content.splitlines() if line.strip()]

    # 定位表头
    header_idx = -1
    for i, line in enumerate(lines):
        if line.startswith("#HostName") or line.startswith("HostName"):
            header_idx = i
            break

    if header_idx == -1:
        print("[!] 未找到有效 CSV 表头", file=sys.stderr)
        return []

    headers = [h.strip().lower() for h in lines[header_idx].lstrip("#*").split(",")]

    try:
        idx_host = headers.index("hostname")
        idx_ip = headers.index("ip")
        idx_c_short = headers.index("countryshort")
        idx_c_long = headers.index("countrylong")
        idx_operator = headers.index("operator") if "operator" in headers else -1
        idx_b64 = next(i for i, h in enumerate(headers) if "base64" in h or "config" in h)
    except (ValueError, StopIteration) as e:
        print(f"[!] 表头缺少必要字段: {e}", file=sys.stderr)
        return []

    raw_candidates = []
    tcp_regex = re.compile(r"^proto\s+(tcp|tcp4|tcp6)\b", re.I | re.M)
    port_regex = re.compile(r"^remote\s+\S+\s+(\d+)", re.I | re.M)

    for line in lines[header_idx + 1:]:
        if line.startswith("*"):
            break

        parts = list(csv.reader([line]))[0]
        if len(parts) <= max(idx_host, idx_ip, idx_c_short, idx_c_long, idx_b64):
            continue

        raw_host = parts[idx_host].strip()
        ip = parts[idx_ip].strip()
        c_short = parts[idx_c_short].strip().upper()
        c_long = parts[idx_c_long].strip()
        operator = parts[idx_operator].strip() if idx_operator != -1 and idx_operator < len(parts) else ""
        b64_data = parts[idx_b64].strip()

        if not b64_data:
            continue

        # 解析 OpenVPN 配置，判断是否支持 TCP 协议并提取端口
        try:
            cfg_text = base64.b64decode(b64_data).decode("utf-8", errors="ignore")
        except Exception:
            continue

        if not tcp_regex.search(cfg_text):
            continue

        port_match = port_regex.search(cfg_text)
        if not port_match:
            continue

        port = port_match.group(1)

        # 中文地区名称映射
        zh_country = GEO_NAMES_ZH.get(c_short, c_long or c_short)

        raw_candidates.append({
            "host": raw_host,
            "ip": ip,
            "port": port,
            "country": zh_country,
            "operator": operator
        })

    if not raw_candidates:
        print("[!] 未筛选出支持 TCP/SSTP 的节点")
        return []

    # 去重（按 IP + 端口）
    unique_candidates = []
    seen = set()
    for c in raw_candidates:
        key = f"{c['ip']}:{c['port']}"
        if key not in seen:
            seen.add(key)
            unique_candidates.append(c)

    # 拉取并融合自定义源（URL或本地文件）
    raw_custom_nodes = fetch_custom_nodes(custom_sources)

    # 收集需要查询地理与家宽属性的 IP（包含 VPNGate 与没有 #备注 的自定义节点）
    isp_map = {}
    if check_isp:
        unique_ips = list(dict.fromkeys(c["ip"] for c in unique_candidates))
        for cn in raw_custom_nodes:
            if "#" not in cn:
                host = extract_node_host(cn)
                ip = host
                if not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", host):
                    try:
                        ip = socket.gethostbyname(host)
                    except Exception:
                        ip = None
                if ip and ip not in unique_ips:
                    unique_ips.append(ip)
        isp_map = batch_query_isp_type(unique_ips)

    results = []
    for c in unique_candidates:
        ip = c["ip"]
        port = c["port"]
        country = c["country"]

        # 确定家宽/机房标签
        if check_isp:
            isp_item = isp_map.get(ip) or {}
            tag = isp_item.get("tag")
            if not tag:
                tag = "机房" if HOSTING_KEYWORDS_REGEX.search(c["operator"]) else "家宽"
        else:
            tag = "机房" if HOSTING_KEYWORDS_REGEX.search(c["operator"]) else "家宽"

        # 拼接地址（域名或纯 IP）
        if use_ip:
            addr = ip
        else:
            addr = c["host"] if c["host"].endswith(".opengw.net") else f"{c['host']}.opengw.net"

        # 格式示例：sstp://vpn:vpn@vpn407145859.opengw.net:1743#日本-家宽
        node_str = f"sstp://vpn:vpn@{addr}:{port}#{country}-{tag}"
        results.append(node_str)

    print(f"[+] VPNGate 官方源提取完成！共得到 {len(results)} 个有效 SSTP 节点")

    # 对未带 #备注 的自定义节点补充国家地区和机房/家宽标签
    custom_nodes = []
    for cn in raw_custom_nodes:
        if "#" in cn:
            custom_nodes.append(cn)
        else:
            host = extract_node_host(cn)
            ip = host
            if not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", host):
                try:
                    ip = socket.gethostbyname(host)
                except Exception:
                    ip = None
            isp_info = (isp_map.get(ip) if ip else None) or {}
            c_code = isp_info.get("country_code", "")
            c_name = isp_info.get("country", "")
            is_dc = (isp_info.get("tag") == "机房")
            if c_code or c_name:
                tag = format_node_tag(c_code, c_name, is_dc)
                custom_nodes.append(f"{cn}#{tag}")
            else:
                custom_nodes.append(cn)

    # 合并去重（自定义源优先置顶）
    merged_candidates = []
    seen_keys = set()

    for node in custom_nodes + results:
        key = normalize_node_key(node)
        if key not in seen_keys:
            seen_keys.add(key)
            merged_candidates.append(node)

    print(f"[+] 多源合并去重完成：共 {len(merged_candidates)} 个候选节点 (自定义源: {len(custom_nodes)}，VPNGate: {len(results)})")

    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write("\n".join(merged_candidates) + "\n")
        print(f"[+] 全部候选节点已导出到: {output_file}")

    if check_alive:
        alive_results = check_sstp_alive(
            merged_candidates,
            api_url=api_url,
            token=token,
            chunk_size=chunk_size,
            output_file=alive_output_file
        )
        return alive_results

    return merged_candidates

def check_sstp_alive(nodes, api_url=PROBE_API_URL, token=PROBE_TOKEN, chunk_size=25, timeout=60, output_file="alive_sstp.txt"):
    """
    调用 VPS 探测 API (/check/batch) 进行批量存活检测
    过滤出真实可用（完整协议握手 + 目标站点访问成功）的节点并导出
    """
    if not nodes:
        print("[!] 没有待检测的节点", file=sys.stderr)
        return []

    if not api_url:
        print("[!] 未配置 PROBE_API_URL，跳过测活", file=sys.stderr)
        return []

    batch_url = f"{api_url}/check/batch"
    total = len(nodes)
    print(f"\n[*] 开始通过 VPS 探测 API 进行真实连通性测活...")
    print(f"[*] API 地址: {batch_url}")
    print(f"[*] 待测节点: {total} 个，每批次大小: {chunk_size}")
    print("-" * 75)

    headers = {
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    alive_nodes = []
    dead_count = 0
    start_time = time.time()

    for idx in range(0, total, chunk_size):
        chunk = nodes[idx:idx + chunk_size]
        batch_num = idx // chunk_size + 1
        total_batches = (total + chunk_size - 1) // chunk_size
        print(f"[*] 正在探测第 {batch_num}/{total_batches} 批 ({len(chunk)} 个节点)...")

        payload = {"targets": chunk}
        data = json.dumps(payload).encode("utf-8")

        try:
            req = urllib.request.Request(batch_url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp_data = json.loads(resp.read().decode("utf-8"))

            results = resp_data.get("results", [])
            for r in results:
                target = r.get("input") or r.get("link") or ""
                success = r.get("success", False)
                resp_ms = r.get("responseTime", 0)

                if success:
                    exit_info = r.get("exit") or {}
                    exit_ip = exit_info.get("ip", "-")
                    exit_country = exit_info.get("country", "-")
                    exit_country_code = exit_info.get("country_code", "")
                    is_dc = exit_info.get("is_datacenter", False)

                    # 根据 VPS 探测到的真实出口生成统一标签（如：加拿大-机房、日本-家宽）
                    real_tag = format_node_tag(exit_country_code, exit_country, is_dc)

                    # 统一保留或赋予 #{国家}-{机房/家宽} 格式
                    base_uri = target.split("#")[0].strip()
                    final_node = f"{base_uri}#{real_tag}"

                    try:
                        print(f"  [+] 存活 | {resp_ms:4d}ms | {exit_country} ({exit_ip}) | {final_node}")
                    except Exception:
                        print(f"  [+] 存活 | {resp_ms:4d}ms | {final_node}")
                    alive_nodes.append(final_node)
                else:
                    err = r.get("error") or "未知错误"
                    try:
                        print(f"  [-] 离线 | {resp_ms:4d}ms | {err} | {target}")
                    except Exception:
                        print(f"  [-] 离线 | {resp_ms:4d}ms | {target}")
                    dead_count += 1

        except urllib.error.HTTPError as e:
            err_msg = e.read().decode("utf-8", errors="ignore")
            print(f"  [!] 本批请求失败 (HTTP {e.code}): {err_msg}", file=sys.stderr)
            dead_count += len(chunk)
        except Exception as e:
            print(f"  [!] 本批请求异常: {e}", file=sys.stderr)
            dead_count += len(chunk)

    elapsed = time.time() - start_time
    alive_count = len(alive_nodes)
    print("-" * 75)
    print(f"[+] 测活完成！耗时: {elapsed:.1f}s | 候选: {total} | 存活: {alive_count} | 失败: {dead_count}")

    if output_file and alive_nodes:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write("\n".join(alive_nodes) + "\n")
        print(f"[+] 存活节点已成功保存到: {output_file}")
    elif not alive_nodes:
        print(f"[!] 本轮未探测到存活节点，未写入 {output_file}")

    return alive_nodes

if __name__ == "__main__":
    # use_ip=False 保留 .opengw.net 域名（推荐，有 SNI 保证）
    # check_isp=True 批量查询准确区分【家宽】与【机房】
    # check_alive=True 开启 VPS 接口真实存活测试，结果保存到 alive_sstp.txt
    fetch_vpngate_sstp(
        use_ip=False,
        check_isp=True,
        output_file="sstp_nodes.txt",
        check_alive=True,
        alive_output_file="alive_sstp.txt"
    )

